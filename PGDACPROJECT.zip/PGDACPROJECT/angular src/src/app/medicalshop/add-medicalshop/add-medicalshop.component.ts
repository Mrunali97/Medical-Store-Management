import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MedicalShopService } from '../medical-shop.service';
import { MedicalShop } from '../medicalshop.model';

@Component({
  selector: 'app-add-medicalshop',
  templateUrl: './add-medicalshop.component.html',
  styleUrls: ['./add-medicalshop.component.css']
})
export class AddMedicalshopComponent implements OnInit {

  constructor(private router:Router,private service:MedicalShopService) { }

  shops:MedicalShop=new MedicalShop();
  submitted

  ngOnInit(): void {
  }
  saveMedicalShop() {
    this.service.createMedicalShop(this.shops)
      .subscribe(data => console.log(data), error => console.log(error));
    this.shops = new MedicalShop();
    this.gotoList();
  }

  onSubmit() {
    this.saveMedicalShop();    
  }

  gotoList(){
    this.router.navigate(['/medicalshop']);
  }
}
