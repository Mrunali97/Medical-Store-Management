
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MedicalShopService } from '../medical-shop.service';
import { MedicalShop } from '../medicalshop.model';
import {NgForm} from '@angular/forms';

@Component({
  selector: 'app-loginowner',
  templateUrl: './loginowner.component.html',
  styleUrls: ['./loginowner.component.css']
})
export class LoginownerComponent implements OnInit {

  owner:MedicalShop=new MedicalShop();

  submitted
  ownerId:any;
  constructor(private router:Router,private service:MedicalShopService) { }

  
  ngOnInit(): void {

  }
  GetValidOwner() {
    this.service.getOwnerLogin(this.owner)
      .subscribe(data => console.log(data), error => console.log(error));
     this.owner = new MedicalShop();
    this.gotoList();
  }

  onSubmit() {
    this.GetValidOwner();    
  }

  gotoList(){
    this.router.navigate(['displayowner']);
  }
}
