import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ShowmedicalshopsComponent } from './showmedicalshops.component';

describe('ShowmedicalshopsComponent', () => {
  let component: ShowmedicalshopsComponent;
  let fixture: ComponentFixture<ShowmedicalshopsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowmedicalshopsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowmedicalshopsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
