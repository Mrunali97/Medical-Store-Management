import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShowmedicalshopsComponent } from './showmedicalshops/showmedicalshops.component';
import { UpdateMedicalshopComponent } from './update-medicalshop/update-medicalshop.component';
import { DetailsMedicalshopComponent } from './details-medicalshop/details-medicalshop.component';
import { AddMedicalshopComponent } from './add-medicalshop/add-medicalshop.component';
import { LoginownerComponent } from './loginowner/loginowner.component';
import { DisplayPageComponent } from './display-page/display-page.component';
import { FormsModule } from '@angular/forms';




@NgModule({
  declarations: [ShowmedicalshopsComponent, UpdateMedicalshopComponent, DetailsMedicalshopComponent, AddMedicalshopComponent, LoginownerComponent, DisplayPageComponent],
  imports: [
    CommonModule,
    FormsModule
  ]
})
export class MedicalshopModule { }
