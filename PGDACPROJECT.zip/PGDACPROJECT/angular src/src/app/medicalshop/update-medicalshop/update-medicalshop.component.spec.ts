import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateMedicalshopComponent } from './update-medicalshop.component';

describe('UpdateMedicalshopComponent', () => {
  let component: UpdateMedicalshopComponent;
  let fixture: ComponentFixture<UpdateMedicalshopComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateMedicalshopComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateMedicalshopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
