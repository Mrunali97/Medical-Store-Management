import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Staff } from '../staff.model';
import { StaffService } from '../staff.service';

@Component({
  selector: 'app-update-staff',
  templateUrl: './update-staff.component.html',
  styleUrls: ['./update-staff.component.css']
})
export class UpdateStaffComponent implements OnInit {
  staffid:number;
  staff:Staff;

  constructor(private route:ActivatedRoute,private router:Router,
              private service:StaffService) { }

  ngOnInit(): void {
    this.staff=new Staff();
    this.staffid=this.route.snapshot.params['staffId'];

    this.service.getStaffDetailsById(this.staffid)
    .subscribe(data=>{
      console.log(data)
      this.staff=data;
    },error=>console.error(error) );
  }
  updateCompany()
  {
    this.service.updateStaffDetails(this.staffid)
    .subscribe(data=>console.log(data),error=>console.log(error));
    this.staff=new Staff();
    this.gotoList();
  }
  onSubmit() {
    this.updateCompany();    
  }

  gotoList() {
    this.router.navigate(['/displayowner/staff']);
  }
}
