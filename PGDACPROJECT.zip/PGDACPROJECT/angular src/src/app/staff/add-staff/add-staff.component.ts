import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginownerComponent } from 'src/app/medicalshop/loginowner/loginowner.component';
import { Staff } from '../staff.model';
import { StaffService } from '../staff.service';

@Component({
  selector: 'app-add-staff',
  templateUrl: './add-staff.component.html',
  styleUrls: ['./add-staff.component.css']
})
export class AddStaffComponent implements OnInit {
  shopId:number;
  constructor(private service:StaffService,private router:Router) { }
   
  staff:Staff=new Staff();
  submitted
 
  ngOnInit(): void {
      }
  saveStaff() {
  
    this.service.AddNewStaff(this.staff)
      .subscribe(data => console.log(data), error => console.log(error));
    this.staff = new Staff();
    this.gotoList();
  }
    onSubmit() {
      this.saveStaff();    
    }
  
    gotoList(){
      this.router.navigate(['displayowner/staff']);
    }
}
