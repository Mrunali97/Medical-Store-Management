import { Component, OnInit } from '@angular/core';
import { StaffService } from '../staff.service';

@Component({
  selector: 'app-display-staff',
  templateUrl: './display-staff.component.html',
  styleUrls: ['./display-staff.component.css']
})
export class DisplayStaffComponent implements OnInit {
  IsSatffLogin:any;
  constructor(private service:StaffService) { }

  ngOnInit(): void {
    this.IsSatffLogin=this.service.getStaffLogin;
  }

}
