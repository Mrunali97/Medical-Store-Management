import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StaffService {
  private baseUrl = 'http://localhost:8080';

  constructor(private http:HttpClient) { }

  AddNewStaff(staff:Object): Observable<Object> {
    console.log(staff);
    return this.http.post(this.baseUrl+'/staff/', staff);
  }

  updateStaffDetails(staff: Object): Observable<Object> {
    console.log(staff);
    return this.http.put(this.baseUrl+'/staff/', staff);
  }

  deleteStaffById(staffId:number): Observable<any> {
    return this.http.delete(this.baseUrl+'/staff/'+staffId);
  }

  getStaffList(): Observable<any> {
    return this.http.get(this.baseUrl+'/staff/');
  }
  getStaffDetailsById(staffid: number): Observable<any> {
    return this.http.get(this.baseUrl+'/staff/'+staffid);
  }

  getStaffLogin(staff:Object):Observable<Object>{
    return this.http.post(this.baseUrl+'/staff/stafflogin/', staff);
  }
}
