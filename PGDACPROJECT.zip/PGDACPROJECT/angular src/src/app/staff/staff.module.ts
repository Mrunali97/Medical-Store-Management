import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShowStaffComponent } from './show-staff/show-staff.component';
import { AddStaffComponent } from './add-staff/add-staff.component';
import { UpdateStaffComponent } from './update-staff/update-staff.component';
import { DetailsStaffComponent } from './details-staff/details-staff.component';
import { StaffLoginComponent } from './staff-login/staff-login.component';
import { DisplayStaffComponent } from './display-staff/display-staff.component';



@NgModule({
  declarations: [ShowStaffComponent, AddStaffComponent, UpdateStaffComponent, DetailsStaffComponent, StaffLoginComponent, DisplayStaffComponent],
  imports: [
    CommonModule
  ]
})
export class StaffModule { }
