import { TestModuleMetadata } from "@angular/core/testing";
import { MedicalShopService } from "../medicalshop/medical-shop.service";
import { MedicalShop } from "../medicalshop/medicalshop.model";

export class Staff extends MedicalShop{
    staffId:number;
    medicineShopId:number;
    staffName:string;
    staffMobile:string;
    staffEmail:string;
    staffPassword:string;
    staffAddress:string;
    staffSalary:number
}