import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Staff } from '../staff.model';
import { StaffService } from '../staff.service';

@Component({
  selector: 'app-staff-login',
  templateUrl: './staff-login.component.html',
  styleUrls: ['./staff-login.component.css']
})
export class StaffLoginComponent implements OnInit {

  staff:Staff=new Staff();

  submitted
  ownerId:any;
  constructor(private router:Router,private service:StaffService) { }

  ngOnInit(): void {
  }
  GetValidSatff() {
    this.service.getStaffLogin(this.staff)
      .subscribe(data => console.log(data), error => console.log(error));
     this.staff = new Staff();
    this.gotoList();
  }

  onSubmit() {
    this.GetValidSatff();    
  }

  gotoList(){
    this.router.navigate(['staffdisplay']);
  }
}
