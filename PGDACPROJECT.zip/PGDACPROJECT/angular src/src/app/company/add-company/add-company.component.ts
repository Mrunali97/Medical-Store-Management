import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Company } from '../company.model';
import { CompanyService } from '../company.service';

@Component({
  selector: 'app-add-company',
  templateUrl: './add-company.component.html',
  styleUrls: ['./add-company.component.css']
})
export class AddCompanyComponent implements OnInit {
  
  constructor(private service:CompanyService,private router:Router) { }
  
  company:Company=new Company();
  submitted

  ngOnInit(): void {
  }
  saveCompany() {
    this.service.AddNewCompany(this.company)
      .subscribe(data => console.log(data), error => console.log(error));
    this.company = new Company();
    this.gotoList();
  }
    onSubmit() {
      this.saveCompany();    
    }
  
    gotoList(){
      this.router.navigate(['displayowner/company']);
    }
}
