import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Company } from '../company.model';
import { CompanyService } from '../company.service';

@Component({
  selector: 'app-show-company',
  templateUrl: './show-company.component.html',
  styleUrls: ['./show-company.component.css']
})
export class ShowCompanyComponent implements OnInit {
  companies:Observable<Company[]>;
  constructor(private service:CompanyService,private router:Router) { }

  ngOnInit(): void {
    this.fetchCompanyList();
  }
  fetchCompanyList()
  {
    this.companies=this.service.getCompanyList();
  }

  deleteCompany(companyid: number) {
   this.service.deleteCompany(companyid)
     .subscribe(
       data => {
         console.log(data);
         this.fetchCompanyList();
       },
       error => console.log(error));
 }

 CompanyDetails(companyid: number) {
   this.router.navigate(['companydetails', companyid]);
 }

 updateCompanyDetails(company:Company){
   this.router.navigate(['updatecompany', company]);
 }
}
