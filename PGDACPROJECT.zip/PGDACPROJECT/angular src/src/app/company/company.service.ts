import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CompanyService {
  private baseUrl = 'http://localhost:8080';
  constructor(private http:HttpClient) { }

  AddNewCompany(company:Object): Observable<Object> {
    return this.http.post(this.baseUrl+'/company/', company);
  }

  updateCompanyDetails(company: Object): Observable<Object> {
    return this.http.put(this.baseUrl+'/company/', company);
  }

  deleteCompany(companyId:number): Observable<any> {
    return this.http.delete(this.baseUrl+'/company/'+companyId);
  }

  getCompanyList(): Observable<any> {
    return this.http.get(this.baseUrl+'/company/');
  }
  getCompany(companyid: number): Observable<any> {
    return this.http.get(this.baseUrl+'/company/'+companyid);
  }
}
