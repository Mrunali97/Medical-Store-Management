import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Company } from '../company.model';
import { CompanyService } from '../company.service';

@Component({
  selector: 'app-details-company',
  templateUrl: './details-company.component.html',
  styleUrls: ['./details-company.component.css']
})
export class DetailsCompanyComponent implements OnInit {
   companyid:number;
   company:Company;
  constructor(private route:ActivatedRoute,private router:Router,
               private service:CompanyService) { }

  ngOnInit(): void {

    this.company=new Company();
    this.companyid=this.route.snapshot.params['companyId'];

    this.service.getCompany(this.companyid)
    .subscribe(data => {
      console.log(data)
      this.company = data;
    }, error => console.log(error));
  }
  list() {
    this.router.navigate(['displayowner/company']);
  }
}
