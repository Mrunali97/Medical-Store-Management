import { Company } from "../company/company.model";
import { MedicalShop } from "../medicalshop/medicalshop.model";

export class Medicine {
    medicineId:number;
    medicalShopId:number;
    medicineName:string;
    companyId:number;
    availbleStocks:number;
    minimumStocks:number;
    medicineCost:number;
    mfgDate:Date;
    expDate:Date;
    medicineDescription:string;

}
