import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Medicine } from '../medicine';
import { MedicinesService } from '../medicines.service';

@Component({
  selector: 'app-update-medicine',
  templateUrl: './update-medicine.component.html',
  styleUrls: ['./update-medicine.component.css']
})
export class UpdateMedicineComponent implements OnInit {
  medicineId:number;
  medicine:Medicine;

  constructor(private route:ActivatedRoute,private router:Router,
    private service:MedicinesService) { }

  ngOnInit(): void {
    this.medicine=new Medicine();
    this.medicineId=this.route.snapshot.params['medicineId'];

    this.service.getMedicineById(this.medicineId)
    .subscribe(data=>{
      console.log(data)
      this.medicine=data;
    },error=>console.error(error) );
  }
  updateMedicines()
  {
    this.service.updateMedicineDetails(this.medicineId)
       .subscribe(data=>console.log(data),error=>console.log(error));
    this.medicine=new Medicine();
    this.gotoList();
  }
  onSubmit() {
    this.updateMedicines();    
  }

  gotoList() {
    this.router.navigate(['/staffdisplay']);
  }
}
