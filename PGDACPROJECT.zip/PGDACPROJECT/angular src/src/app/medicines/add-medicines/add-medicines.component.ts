import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Medicine } from '../medicine';
import { MedicinesService } from '../medicines.service';

@Component({
  selector: 'app-add-medicines',
  templateUrl: './add-medicines.component.html',
  styleUrls: ['./add-medicines.component.css']
})
export class AddMedicinesComponent implements OnInit {

  constructor(private router:Router,private service:MedicinesService) { }

  medicines:Medicine=new Medicine();
  submitted


  ngOnInit(): void {
  }
  saveMedicines() {
    this.service.AddNewMedcine(this.medicines)
      .subscribe(data => console.log(data), error => console.log(error));
    this.medicines = new Medicine();
    this.gotoList();
  }

  onSubmit() {
    this.saveMedicines();    
  }

  gotoList(){
    this.router.navigate(['staffdisplay/medicines']);
  }

}
