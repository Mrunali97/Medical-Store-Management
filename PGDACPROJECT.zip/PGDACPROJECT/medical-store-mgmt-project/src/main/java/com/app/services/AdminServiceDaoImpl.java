package com.app.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.AdminRepository;

import com.app.pojos.Administrator;


@Service
@Transactional
public class AdminServiceDaoImpl implements IAdministratorService {
	
	  @Autowired
		private AdminRepository repo;
		

	@Override
	public Administrator fetchLoginAdmin(String email, String Pass) {
		Administrator admin=repo.findByadminEmail(email);
		admin=repo.findByadminPassword(Pass);
       return admin;
	}

}
