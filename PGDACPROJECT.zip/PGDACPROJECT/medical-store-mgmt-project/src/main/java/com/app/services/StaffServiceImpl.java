package com.app.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.StaffRepository;
import com.app.pojos.MedicalShop;
import com.app.pojos.Staff;

import custome_exception.CompanyNotFoundException;
import custome_exception.StaffNotFoundException;

@Service
@Transactional
public class StaffServiceImpl implements IStaffService {

	@Autowired
	private StaffRepository repo;
	
	@Override
	public Staff addNewStaff(Staff s) {
		return repo.save(s);
	}

	@Override
	public List<Staff> getAllStaff() {
	
		return repo.findAll();
	}

	@Override
	public Staff updateStaffDetails(Staff s) {
		Optional<Staff> optional=repo.findByStaffName(s.getStaffName());
		if(optional.isPresent())
		return repo.save(s);
		else
		throw new StaffNotFoundException("Staff not found : Invalid staff name"+s.getStaffName());
	}

	@Override
	public void deleteStaff(int staffId) {

		Optional<Staff> optional = repo.findById(staffId);
		if(optional.isPresent())
			repo.deleteById(staffId);
		else
		throw new StaffNotFoundException("Staff not found : Invalid staff id"+staffId);

	}

	@Override
	public Staff getStaffDetails(int staffId) {
		Optional<Staff> optionalProduct = repo.findById(staffId);
		if (optionalProduct.isPresent())
			return repo.getOne(staffId);
		else
		throw new CompanyNotFoundException("Staff Details Not Found: Invalid ID " + staffId);
	}

	@Override
	public Staff fetchLoginStaff(String email, String Pass) {
		Staff staff=repo.findByStaffEmail(email);
        staff=repo.findByStaffPassword(Pass);
       return staff;
	}

}
