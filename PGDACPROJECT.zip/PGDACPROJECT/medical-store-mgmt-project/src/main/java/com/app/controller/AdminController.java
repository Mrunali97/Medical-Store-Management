package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.pojos.Administrator;

import com.app.services.IAdministratorService;

import custome_exception.AdminNotFoundException;



@RestController
@RequestMapping("/admin")
@CrossOrigin
public class AdminController {

	@Autowired
	private IAdministratorService service;
	public AdminController() {
		System.out.println("in def contr of "+getClass().getName());
	}
	@PostMapping("/adminlogin")
	public Administrator LoginAdmin(@RequestBody Administrator a )
	{
		System.out.println("in LoginAdmin "+a);
		String email=a.getAdminEmail();
		String pass=a.getAdminPassword();
		Administrator admin=null;
		if(email!=null && pass!=null)
			admin=service.fetchLoginAdmin(email, pass);
		if(admin==null)
			throw new AdminNotFoundException("Wrong Credentils ... Please try again");
		return admin;
	}
}
