package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import com.app.pojos.MedicalShop;
import com.app.services.IMedicalShopService;

import custome_exception.MedicalShopNotFoundException;

@RestController
@RequestMapping("/medicalshop")
@CrossOrigin
public class MedicalShopController {
	
	@Autowired
	private IMedicalShopService service;
	
	public MedicalShopController() {
	System.out.println("in contrl of "+getClass().getName());
	}
	
	@PostMapping("/ownerlogin")
	public MedicalShop LoginOwner(@RequestBody MedicalShop m )
	{
		System.out.println("in LoginOwner "+m);
		String email=m.getOwnerEmail();
		String pass=m.getOwnerPassword();
		MedicalShop owner=null;
		if(email!=null && pass!=null)
			owner=service.fetchLoginOwner(email, pass);	
		if(owner==null)
			throw new MedicalShopNotFoundException("Wrong Credentils ... Please try again");
		return owner;
	}
	@GetMapping
	public ResponseEntity<?> MedicalShopList() {
		System.out.println("in list medicalshop list " );
	    List<MedicalShop> shops=service.getAllMedicalShops();
		if(shops.isEmpty())
		    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		else
			return new ResponseEntity<>(shops,HttpStatus.OK);
		
	}
	
	@PostMapping
	public ResponseEntity<?> addNewMedicalShop(@RequestBody MedicalShop ms)
	{
		System.out.println("in addnewshop "+ms);
		return ResponseEntity.ok(service.addMedicalShop(ms));
	}

	
	
	@PutMapping
	public ResponseEntity<?> updateMedicalShopDetails(@RequestBody MedicalShop ms) {
		System.out.println("in update medicalshop " + ms);
		try {
			return ResponseEntity.ok(service.UpdateShopDetails(ms));
		} catch (RuntimeException e) {
			System.out.println("err in controller " + e);
		}
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
	@DeleteMapping("/{shopid}")
	public void deleteMedicalShopDetails(@PathVariable int shopid) {
		System.out.println("in del medicalshop dtls " + shopid);
		try {
			service.deleteMedicalShop(shopid);
			
		} catch (RuntimeException e) {
			System.out.println("err in controller " + e);
		}
	}
	
	
	@GetMapping("/{shopid}")
	public ResponseEntity<?> getMedicalShopDetails(@PathVariable int shopid) {
		System.out.println("in get shop dtls " + shopid);
		try {
			return ResponseEntity.ok(service.getMedicalshopDetails(shopid));
		} catch (RuntimeException e) {
			System.out.println("err in controller " + e);
		}
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
}
