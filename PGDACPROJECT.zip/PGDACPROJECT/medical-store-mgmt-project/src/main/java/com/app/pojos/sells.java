package com.app.pojos;

import javax.persistence.*;

@Entity
@Table(name="sells")
public class sells {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="sell_id")
	private Integer sellId;
	
	@ManyToOne
	@JoinColumn(name = "medical_shop__id", nullable = false)
	private MedicalShop medicalShopId;

	@Column(length =200,name=" sell_name")
	private String sellName;
	
	@Column(length =20,name="sell_number")
	private Integer sellNumber;
	
	@Column(length =200,name="sell_description")
	private String sellDescription;


	public sells(String sellName, Integer sellNumber, String sellDescription) {
		super();
		this.sellName = sellName;
		this.sellNumber = sellNumber;
		this.sellDescription = sellDescription;
	}

	public String getSellName() {
		return sellName;
	}

	public void setSellName(String sellName) {
		this.sellName = sellName;
	}

	public Integer getSellNumber() {
		return sellNumber;
	}

	public void setSellNumber(Integer sellNumber) {
		this.sellNumber = sellNumber;
	}

	public String getSellDescription() {
		return sellDescription;
	}

	public void setSellDescription(String sellDescription) {
		this.sellDescription = sellDescription;
	}

	public Integer getSellId() {
		return sellId;
	}

	public MedicalShop getMedicalShopId() {
		return medicalShopId;
	}

	@Override
	public String toString() {
		return "sells [sellId=" + sellId + ", medicalShopId=" + medicalShopId + ", sellName=" + sellName
				+ ", sellNumber=" + sellNumber + ", sellDescription=" + sellDescription + "]";
	}


}
