package com.app.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;


import com.app.pojos.Staff;

public interface StaffRepository extends JpaRepository<Staff,Integer>{
Optional<Staff> findByStaffName(String staffname);
public Staff findByStaffEmail(String email);
public Staff findByStaffPassword(String pass);

}
