package com.app.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.MedicalShopRepository;
import com.app.pojos.MedicalShop;

import custome_exception.MedicalShopNotFoundException;

@Service
@Transactional
public class MedicalShopServiceImpl implements IMedicalShopService {

    @Autowired
	private MedicalShopRepository repo;
	
	@Override
	public MedicalShop addMedicalShop(MedicalShop ms) {

		return repo.save(ms);
	}

	@Override
	public List<MedicalShop> getAllMedicalShops() {
	
		return repo.findAll();
	}

	@Override
	public MedicalShop UpdateShopDetails(MedicalShop ms) {
		Optional<MedicalShop> optional=repo.findByMedicalShopName(ms.getMedicalShopName());
		if(optional.isPresent())
		return repo.save(ms);
		else
		throw new MedicalShopNotFoundException("Medical Shop not found : Invalid shop name"+ms.getMedicalShopName());
			
	}

	@Override
	public void deleteMedicalShop(int shopid) {
	
		Optional<MedicalShop> optional = repo.findById(shopid);
		if(optional.isPresent())
			repo.deleteById(shopid);
		else
		throw new MedicalShopNotFoundException("Medical Shop not found : Invalid shop id"+shopid);
	}

	@Override
	public MedicalShop getMedicalshopDetails(int shopId) {
		Optional<MedicalShop> optionalShop = repo.findById(shopId);
		if (optionalShop.isPresent())
			return repo.getOne(shopId);
		else
		throw new MedicalShopNotFoundException("Medical Shop not found : Invalid ID " + shopId);
	}

	@Override
	public MedicalShop fetchLoginOwner(String email, String Pass) {
		MedicalShop owner=repo.findByOwnerEmail(email);
		         owner=repo.findByOwnerPassword(Pass);
		return owner;
	}

	

}
