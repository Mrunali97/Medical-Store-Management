package com.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedicalStoreMgmtProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedicalStoreMgmtProjectApplication.class, args);
	}

}
