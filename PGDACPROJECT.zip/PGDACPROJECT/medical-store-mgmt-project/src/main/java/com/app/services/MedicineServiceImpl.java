package com.app.services;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.MedicinesRepository;

import com.app.pojos.Medicines;

import custome_exception.MedicineNotFoundException;

@Service
@Transactional
public class MedicineServiceImpl implements IMedicineService {
	
	@Autowired
	private MedicinesRepository repo;

	@Override
	public Medicines addNewMedicines(Medicines m) {

		return repo.save(m);
	}

	@Override
	public List<Medicines> getAllMedicines() {

		return repo.findAll();
	}

	@Override
	public Medicines updateMedicineDetails(Medicines m) {
		Optional<Medicines> optional=repo.findByMedicineName(m.getMedicineName());
		if(optional.isPresent())
		return repo.save(m);
		else
		throw new MedicineNotFoundException("Medicines not found : Invalid Medicine name"+m.getMedicineName());
	}

	@Override
	public void deleteMedicine(int medicineId) {
		Optional<Medicines> optional = repo.findById(medicineId);
		if(optional.isPresent())
			repo.deleteById(medicineId);
		else
		throw new  MedicineNotFoundException("Medicines not found : Invalid medicine id"+medicineId);
		
	}

	@Override
	public Medicines getMedicineDetails(int medicineId) {
		Optional<Medicines> optionalMedicine = repo.findById(medicineId);
		if (optionalMedicine.isPresent())
			return repo.getOne(medicineId);
		else
		throw new MedicineNotFoundException("Medicine not found: Invalid ID " + medicineId);
	}
	

	
}
