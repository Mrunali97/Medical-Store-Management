package com.app.services;

import java.util.List;

import com.app.pojos.MedicalShop;
import com.app.pojos.Staff;

public interface IStaffService {
	Staff addNewStaff(Staff s);
	List<Staff> getAllStaff();
	Staff updateStaffDetails(Staff s);
	void deleteStaff(int staffId);
	Staff  getStaffDetails(int staffId);
	 Staff fetchLoginStaff(String email,String Pass);
}
