package com.app.services;

import java.util.List;


import com.app.pojos.Medicines;

public interface IMedicineService {
	Medicines addNewMedicines(Medicines m);
	List<Medicines> getAllMedicines();
	Medicines updateMedicineDetails(Medicines m);
	void deleteMedicine(int medicineId);
	Medicines  getMedicineDetails(int medicineId);
}
