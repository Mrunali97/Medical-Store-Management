package com.app.pojos;

import javax.persistence.*;

@Entity
@Table(name = "staffs")
public class Staff {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "staff_id")
	private Integer staffId;

	@ManyToOne
	@JoinColumn(name = "medical_shop_id", nullable = false)
	private MedicalShop medicalShopId;

	@Column(length = 50, name = "staff_name")
	private String staffName;

	@Column(length = 10, name = "staff_mobile")
	private String staffMobile;

	@Column(length = 30, unique = true, name = "staff_email")
	private String staffEmail;

	@Column(length = 20, unique = true, name = "staff_password")
	private String staffPassword;

	@Column(length = 50, name = "staff_address")
	private String staffAddress;

	@Column(name = "staff_salary")
	private double staffSalary;

	public Staff() {
		System.out.println("in def costr of " + getClass().getName());
	}

	public Staff(Integer staffId, MedicalShop medicalShopId, String staffName, String staffMobile, String staffEmail,
			String staffPassword, String staffAddress, double staffSalary) {
		super();
		this.staffId = staffId;
		this.medicalShopId = medicalShopId;
		this.staffName = staffName;
		this.staffMobile = staffMobile;
		this.staffEmail = staffEmail;
		this.staffPassword = staffPassword;
		this.staffAddress = staffAddress;
		this.staffSalary = staffSalary;
	}

	public MedicalShop getMedicalShopId() {
		return medicalShopId;
	}

	public void setMedicalShopId(MedicalShop medicalShopId) {
		this.medicalShopId = medicalShopId;
	}

	public String getStaffName() {
		return staffName;
	}

	public void setStaffName(String staffName) {
		this.staffName = staffName;
	}

	public String getStaffMobile() {
		return staffMobile;
	}

	public void setStaffMobile(String staffMobile) {
		this.staffMobile = staffMobile;
	}

	public String getStaffEmail() {
		return staffEmail;
	}

	public void setStaffEmail(String staffEmail) {
		this.staffEmail = staffEmail;
	}

	public String getStaffPassword() {
		return staffPassword;
	}

	public void setStaffPassword(String staffPassword) {
		this.staffPassword = staffPassword;
	}

	public String getStaffAddress() {
		return staffAddress;
	}

	public void setStaffAddress(String staffAddress) {
		this.staffAddress = staffAddress;
	}

	public Integer getStaffId() {
		return staffId;
	}

	public double getStaffSalary() {
		return staffSalary;
	}

	public void setStaffSalary(double staffSalary) {
		this.staffSalary = staffSalary;
	}

	@Override
	public String toString() {
		return "Staff [staffId=" + staffId + ", medicalShopId=" + medicalShopId + ", staffName=" + staffName
				+ ", staffMobile=" + staffMobile + ", staffEmail=" + staffEmail + ", staffPassword=" + staffPassword
				+ ", staffAddress=" + staffAddress + ", staffSalary=" + staffSalary + "]";
	}

	
	

}
