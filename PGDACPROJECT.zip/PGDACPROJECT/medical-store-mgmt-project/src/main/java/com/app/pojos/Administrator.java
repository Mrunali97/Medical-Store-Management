package com.app.pojos;

import javax.persistence.*;

@Entity
@Table(name="administrator")
public class Administrator {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="administrator_id")
	private Integer adminId;
	
	@Column(length =50,name="administrator_name")
	private String adminName;
	
	@Column(length =10,name="administrator_mobile")
	private String adminMobile;
	
	@Column(length = 30,unique = true,name="administrator_email")
	private String  adminEmail ;
	
	@Column(length = 20,unique = true,name="administrator_password")
	private String adminPassword;
	
	public Administrator() {
		System.out.println("in def constr "+getClass().getName());
	}
	public Administrator(int adminId, String adminName, String adminMobile, String adminEmail, String adminPassword) {
		super();
		this.adminId = adminId;
		this.adminName = adminName;
		this.adminMobile = adminMobile;
		this.adminEmail = adminEmail;
		this.adminPassword = adminPassword;
	
	}

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public String getAdminMobile() {
		return adminMobile;
	}

	public void setAdminMobile(String adminMobile) {
		this.adminMobile = adminMobile;
	}

	public String getAdminEmail() {
		return adminEmail;
	}

	public void setAdminEmail(String adminEmail) {
		this.adminEmail = adminEmail;
	}

	public String getAdminPassword() {
		return adminPassword;
	}

	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}

	public Integer getAdminId() {
		return adminId;
	}

	@Override
	public String toString() {
		return "Administrator [adminId=" + adminId + ", adminName=" + adminName + ", adminMobile=" + adminMobile
				+ ", adminEmail=" + adminEmail + ", adminPassword=" + adminPassword 
				+ "]";
	}


	

}
